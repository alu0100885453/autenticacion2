passportjs-example
==================

An example of use PassportJS to login with Twitter &amp; Facebook in Node.js
